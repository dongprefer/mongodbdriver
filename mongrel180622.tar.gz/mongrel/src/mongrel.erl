% Licensed under the Apache License, Version 2.0 (the "License"); you may not
% use this file except in compliance with the License. You may obtain a copy of
% the License at
%
%   http://www.apache.org/licenses/LICENSE-2.0
%
% Unless required by applicable law or agreed to in writing, software
% distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
% WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
% License for the specific language governing permissions and limitations under
% the License.

%%% @author CA Meijer modifed by Weidong Wang to fit to the last mongodriver
%%% @copyright 2012 CA Meijer
%%% @doc Mongrel API. This module provides functions for creating, reading, updating and deleting
%%       documents. The functions exposed are similar to the CRUD functions exposed by the
%%       mongo API of the MongoDB driver. While the mongo functions take collection and document 
%%       arguments, the mongrel functions expect one or more records as arguments. 
%%% @end

-module(mongrel).

-behaviour(gen_server).

%% Includes
-include("mongrel.hrl").

%% API
-export([count/1,
		 count/2,
		 delete/1,
		 %delete_one/1,
		 %do/5,
		 find/1,
		 find/2,
		 find/3,
		 find/4,
		 find_one/1,
		 find_one/2,
		 find_one/3,
		 get_connection_parameters/0,
		 insert/1,
		 insert_all/1,
		 modify/2,
		 replace/2,
		 %repsert/2,
                 update/1,
                 disconnect/0
		 %save/1
		 ]).

%% gen_server callbacks
-export([init/1, 
		 handle_call/3, 
		 handle_cast/2, 
		 handle_info/2, 
		 terminate/2, 
		 code_change/3]).

%-define(DEBUG(F, A), io:format(F++"\n", A)).
-define(DEBUG(_F, _A), "").
%% Types
-type(action() :: fun()).

%% External functions

%% @doc Counts the number of documents that match some selector.
-spec(count(record()) -> integer()).
count(SelectorRecord) ->
	count(SelectorRecord, 0).

get_conn(Collection)->
    SecondaryCollectionList = [octopus_log],
    case lists:member(Collection, SecondaryCollectionList) of
        true ->
            db_connection:get_secondary_conn();
        false ->
            db_connection:get_conn()
    end.

disconnect()->
    Topology = db_connection:get_conn(),
    mongo_api:disconnect(Topology),
    SecondaryTopology = db_connection:get_secondary_conn(),
    mongo_api:disconnect(SecondaryTopology).

%% @doc Counts the number of documents that match some selector up to a specified
%%      maximum. A limit of 0 means that all matching documents are counted.
-spec(count(record(), integer()) -> integer()).
count(SelectorRecord, Limit) ->
     {Collection, Selector} = mongrel_mapper:map(SelectorRecord),
     Pid = get_conn(Collection),
     mongo_api:count(Pid, Collection, Selector, Limit).
	
%% @doc Deletes all documents that match a selector.
-spec(delete(record()) -> ok).
delete(SelectorRecord) ->
    lager:critical("SelectorRecotd= ~p", [SelectorRecord]),
    {Collection, Selector} = mongrel_mapper:map(SelectorRecord),
    %io:format("Collection=~p, Selector =~p~n",[Collection, Selector]),
    Pid = get_conn(Collection),
    mongo_api:delete(Pid, Collection, Selector).

%% @doc Executes an 'action' using the specified read and write modes to a database using a connection.
%%      An 'action' is a function that takes no arguments. The fun will usually invoke functions
%%      to do inserts, finds, modifies, deletes, etc.

%% @doc Finds all documents that match a selector and returns a cursor.
-spec(find(record()) -> mongrel_cursor:cursor()).
find(SelectorRecord) ->
	find(SelectorRecord, #{}).

%% @doc Finds all documents that match a selector and returns a cursor
%%      of a projection. The projection can be passed as a mapped
%%      record or as a Mongo tuple consisting of alternating keys and values.
%%      An empty list ([]) indicates that the full projection of documents must
%%      be returned.
-spec(find(record(), record()) -> mongrel_cursor:cursor()).
find(SelectorRecord, ProjectorRecord) ->
	find(SelectorRecord, ProjectorRecord, 0).

%% @doc Finds all documents that match a selector and returns a cursor
%%      of a projection result. A specified number of matching
%%      documents are skipped. 
-spec(find(record(), record(), integer()) -> mongrel_cursor:cursor()).
find(SelectorRecord, ProjectorRecord, Skip) ->
	find(SelectorRecord, ProjectorRecord, Skip, 0).

%% @doc Finds all documents that match a selector and returns a cursor
%%      of a projection result. A specified number of matching
%%      documents are skipped.  The cursor retrieves results in the specified batch size.
%-spec(find(record(), record(), integer(), integer()) -> mongrel_cursor:cursor()).
%%% output: undefined /map: {#{<<"_id">> => <<"1234">>,<<"name">> => <<"Yankees">>}}
find(SelectorRecord, Projector, Skip, BatchSize = 0) ->
	%{Collection, Selector} = mongrel_mapper:map_selector(Selector),
	{Collection, Selector} = mongrel_mapper:map_selector(SelectorRecord),
        %io:format("~p:find ~p Collection=~p, Selector=~p, Projector=~p, Skip=~p, BatchSize=~p~n", [?MODULE, ?LINE, Collection, Selector, Projector, Skip, BatchSize]),
        Pid = get_conn(Collection),
        Return =  mongo_api:find(Pid, Collection, Selector, Projector, Skip, BatchSize),%or return[]
        case Return of
            {ok, MongoCursor} ->
        	rest({MongoCursor, Collection}, []);
            []->
                  {error, notfound}
         end;
find(SelectorRecord, Projector, Skip, BatchSize) ->
        %{Collection, Selector} = mongrel_mapper:map(SelectorRecord),
        {Collection, Selector} = mongrel_mapper:map_selector(SelectorRecord),
        %io:format("~p:find ~p Collection=~p, Selector=~p, Projector=~p, Skip=~p, BatchSize=~p~n", [?MODULE, ?LINE, Collection, Selector, Projector, Skip, BatchSize]),
        Pid = get_conn(Collection),
        %io:format("Pid = ~p~n",[Pid]),
        Return = mongo_api:find(Pid, Collection, Selector, Projector, Skip, BatchSize),%or return[]
        case Return of 
            {ok, MongoCursor} ->
                  take({MongoCursor, Collection}, BatchSize, []);
            []->
                  {error, notfound}
         end.%BatchSize


take({MongoCursor, Collection}, 0, Docs) ->
     mc_cursor:close(MongoCursor),
     {ok,lists:reverse(Docs)};
take({MongoCursor, Collection}, Limit, Docs) ->
     case mc_cursor:next(MongoCursor) of
             error ->
                      {ok, lists:reverse(Docs)};
              {OneMap} ->
                      Record = mongrel_mapper:unmap(Collection, OneMap),
                      take({MongoCursor, Collection}, Limit-1, [Record|Docs])
      end.

%% output: undefined /map: {#{<<"_id">> => <<"1234">>,<<"name">> => <<"Yankees">>}}
rest({MongoCursor, Collection}, Docs) ->
     case mc_cursor:next(MongoCursor) of
             error ->
                     mc_cursor:close(MongoCursor),
                     {ok,lists:reverse(Docs)};
             {OneMap} ->
                     %io:format("rest onemap=============================~p~n",[OneMap]),
                     Record = mongrel_mapper:unmap(Collection, OneMap),
                     rest({MongoCursor, Collection}, [Record|Docs])
     end.


%% @doc Finds the first document that matches a selector and returns the document as a record.
-spec(find_one(record()) -> record()|{}).
find_one(SelectorRecord) ->
	find_one(SelectorRecord, #{}).

%% @doc Finds the first document that matches a selector and returns a
%%      projection of the document. The empty projection ([]) means
%%      that all fields in the document are populated.  The projection can be 
%%      passed as a mapped record or as a MongoDB tuple consisting of alternating 
%%      keys and values.
-spec(find_one(record(), record()|tuple()) -> record()|{}).
find_one(SelectorRecord, ProjectorRecord) ->
	find_one(SelectorRecord, ProjectorRecord, 0).

%% @doc Finds a document that matches a selector and returns a
%%      projection of the document after skipping a certain number of 
%%      matching documents.
-spec(find_one(record(), record()|tuple(), integer()) -> {record()}).
find_one(SelectorRecord, ProjectorRecord, Skip) ->
	{Collection, Selector} = mongrel_mapper:map(SelectorRecord),
	Projector = #{},%mongrel_mapper:map_projection(ProjectorRecord),
        Pid = get_conn(Collection),
        Res = mongo_api:find_one(Pid, Collection, Selector, Projector), 
        %io:format("Res=~p~n",[Res]),
        case Res of
            undefined ->
               {error, notfound};
            Map when is_map(Map) ->	
               OneRecord = mongrel_mapper:unmap(Collection, Res),
               {ok, OneRecord}
        end.
            

%% @doc Gets the parameters used to read from and write to the database.
%%      It only makes sense to invoke this function from within the process
%%      spawned by the do/5 function.
-spec(get_connection_parameters() -> #mongrel_connection{}).
get_connection_parameters() ->
	get(mongrel_state).

%% @doc Inserts a record into a collection with the same name as the record type. If the 
%%      record contains nested records with '_id' fields, the nested documents are upserted
%%      into their appropriate collections as well. The ID of the inserted document is
%%      returned.
%%%ok
-spec(insert(record()) -> record()).
insert(Record) ->
	{Collection, MapInfo} = mongrel_mapper:map(Record),
        %io:format("Collection, MapInfo = ~p~p~n",[Collection, MapInfo]),
        Pid = get_conn(Collection),
        ReturnMap = mongo_api:insert(Pid, Collection, MapInfo),
        case ReturnMap of
            {{true, ResultCode}, ResultValues} ->
                WriteErrors = maps:find(<<"writeErrors">>, ResultCode),
                case WriteErrors of
                    error ->
                        RecordResult = mongrel_mapper:unmap(Collection,ResultValues),
                        io:format("RecordResult =~p~n",[RecordResult]),
                        {ok, RecordResult};
                    {ok,[HaveErr]} ->
                         Code = maps:get(<<"code">>, HaveErr),
                         {err, Code}
                end
        end.

%% @doc Inserts a list of records into collections with the same name as the corresponding
%%      record type. If a record contains nested records with '_id' fields, the nested documents are 
%%      upserted into their appropriate collections as well. A list of IDs of the inserted documents is
%%      returned.
-spec(insert_all(list(record())) -> list(bson:value())).
insert_all(Records) ->
	[insert(Record) || Record <- Records].
	
%% @doc Updates selected documents using a modifier. The modifier can be specified as a {key, value}
%%      tuple where the key is a modifier and the value is a mapped record (e.g {'$set', #foo{bar=3}}) 
%%      or as a mongo modifier tuple (e.g. {'$set', {bar, 3}).
%-spec(modify(record(), record()) -> ok).
%%% ok, but set the only fields, other will not exist
modify(SelectorRecord, ModifierRecord) ->
	{Collection, SelectorId} = mongrel_mapper:map(SelectorRecord),
        Selector = #{<<"_id">> => maps:get(<<"_id">>, SelectorId)},
        %io:format("===============================Collection =~p, Selector = ~p~n",[Collection, Selector]),
	Doc = mongrel_mapper:get_doc(Collection, ModifierRecord),
        Pid = get_conn(Collection),
        %Opts = #{},
        Opts = #{multi => true},
        %Opts = #{upsert => true},
        %io:format("Doc = ~p, Selector= ~p~n",[Doc, Selector]),
        mongo_api:update(Pid, Collection, Selector, Doc, Opts).


%% @doc Replaces the first document that matches the selector with a new document.
%% remove lator
-spec(replace(record(), record()) -> ok).
replace(SelectorRecord, NewRecord) ->
	{{Collection, NewDocument}, ChildDocuments} = mongrel_mapper:map(NewRecord),
	{Collection, Selector} = mongrel_mapper:map_selector(SelectorRecord),
	mongo:replace(Collection, Selector, NewDocument),
	[mongo:save(ChildCollection, ChildDocument) || {ChildCollection, ChildDocument} <- ChildDocuments].
	
%%%	
update(Record) ->
        {Collection, Doc} = mongrel_mapper:map(Record),
        Pid = get_conn(Collection),
         %Opts = #{},
         Opts = #{multi => true},
        %Opts = #{upsert => true},
        Selector = #{<<"_id">> => maps:get(<<"_id">>, Doc)},
        %io:format("Doc = ~p, Selector= ~p~n",[Doc, Selector]),
        mongo_api:update(Pid, Collection, Selector, Doc, Opts).
%% Server functions

%% @private
%% @doc Initializes the server with a write mode, read mode, a connection and database.
%%      The parameters are stored in the process dictionary so that they can be used
%%      if a connection is needed by a cursor to access collections.
-spec(init([State::#mongrel_connection{}]) -> {ok, State::#mongrel_connection{}}).
init([State]) ->
    {ok, State}.

%% @private
%% @doc Responds synchronously to server calls.  The action of the do/5 function is executed by
%%      this function. The process is stopped after this call.
-spec(handle_call(any(), pid(), #mongrel_connection{}) -> {stop, normal, any(), #mongrel_connection{}}).
handle_call(_Request, _From, State) ->
     Reply = [],
    {stop, normal, Reply, State}.

%% @private
%% @doc Responds asynchronously to messages. The server ignores any asynchronous messages.
-spec(handle_cast(any(), State::#mongrel_connection{}) -> {noreply, State::#mongrel_connection{}}).
handle_cast(_Message, State) ->
	{noreply, State}.

%% @private
%% @doc Responds to out-of-band messages. The server ignores any such messages.
-spec(handle_info(any(), State::#mongrel_connection{}) -> {noreply, State::#mongrel_connection{}}).
handle_info(_Info, State) ->
	{noreply, State}.

%% @private
%% @doc Handles the shutdown of the server.
-spec(terminate(any(), #mongrel_connection{}) -> ok).
terminate(_Reason, _State) ->
	ok.

%% @private
%% @doc Responds to code changes. Any code changes are ignored (the server's state is unchanged).
-spec(code_change(any(), State::#mongrel_connection{}, any()) -> {ok, State::#mongrel_connection{}}).
code_change(_OldVersion, State, _Extra) ->
	{ok, State}.
